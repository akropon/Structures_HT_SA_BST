/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javarealization;

/**
 *
 * @author Akropon
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /*System.out.println("========================================");
        System.out.println("========= TESTIN SORTED ARRAY ==========");
        System.out.println("========================================");
        testing_sorted_array();*/
        
        /*System.out.println("========================================");
        System.out.println("======== TESTING BIN_FIND_TREE =========");
        System.out.println("========================================");
        testing_bin_find_tree();*/
                
        /*System.out.println("========================================");
        System.out.println("========= TESTING HTABLE_CHAIN =========");
        System.out.println("========================================");
        testing_htable_chain(); */
        
        Executor ex = new Executor();
        ex.exec("in.txt", "out.txt");
                
    }
    
    public static void testing_htable_chain() {
        /*int key;
        int ans_i;
        boolean ans_b;
        HTableChain.HChain chain;
        HTableChain hTable_c = new HTableChain(5);
        
        System.out.println(hTable_c.get_current_state());
        System.out.println(hTable_c.get_current_data());
        System.out.println();
        
        System.out.println(">>Add 1, 2, 5, 10, 15, 17, 8, 11, 1, 4");
        hTable_c.add_by_key(1);
        hTable_c.add_by_key(2);
        hTable_c.add_by_key(5);
        hTable_c.add_by_key(10);
        hTable_c.add_by_key(15);
        hTable_c.add_by_key(17);
        hTable_c.add_by_key(8);
        hTable_c.add_by_key(11);
        hTable_c.add_by_key(1);
        hTable_c.add_by_key(4);
        System.out.println(hTable_c.get_current_state());
        System.out.println(hTable_c.get_current_data());
        System.out.println();
        
        System.out.println(">>Del 17");
        ans_b = hTable_c.delete_by_key(17);
        System.out.println("answer = " + ans_b);
        System.out.println(hTable_c.get_current_state());
        System.out.println(hTable_c.get_current_data());
        System.out.println();
        
        System.out.println(">>Find 5");
        chain = hTable_c.find_by_key(5);
        if ( chain == null ) System.out.println("answer = NOT_FOUND");
        else System.out.println("founded chain key = "+chain.key);
        System.out.println(hTable_c.get_current_state());
        System.out.println(hTable_c.get_current_data());
        System.out.println();
        
        System.out.println(">>Find 27");
        chain = hTable_c.find_by_key(27);
        if ( chain == null ) System.out.println("answer = NOT_FOUND");
        else System.out.println("founded chain key = "+chain.key);
        System.out.println(hTable_c.get_current_state());
        System.out.println(hTable_c.get_current_data());
        System.out.println();
        
        System.out.println(">>Find 1");
        chain = hTable_c.find_by_key(1);
        if ( chain == null ) System.out.println("answer = NOT_FOUND");
        else System.out.println("founded chain key = "+chain.key);
        System.out.println(hTable_c.get_current_state());
        System.out.println(hTable_c.get_current_data());
        System.out.println(hTable_c.get_current_data_simple());
        System.out.println();
        
        */
    }
    
    public static void testing_sorted_array() {
        System.out.println(">Creating...");
        SortedArray sArray = new SortedArray(2, 2);
        System.out.println(sArray.get_current_state());
        
        
        System.out.println(">Add 1");
        sArray.add_element(1);
        System.out.println(sArray.get_current_state());
        System.out.println("Data: "+sArray.get_current_data());
        
        
        System.out.println(">Add 4");
        sArray.add_element(4);
        System.out.println(sArray.get_current_state());
        System.out.println("Data: "+sArray.get_current_data());
        
        System.out.println(">Add 8");
        sArray.add_element(8);
        System.out.println(sArray.get_current_state());
        System.out.println("Data: "+sArray.get_current_data());
        
        System.out.println(">Add 2");
        sArray.add_element(2);
        System.out.println(sArray.get_current_state());
        System.out.println("Data: "+sArray.get_current_data());
        
        System.out.println(">Add 3");
        sArray.add_element(3);
        System.out.println(sArray.get_current_state());
        System.out.println("Data: "+sArray.get_current_data());
        
        System.out.println(">Find 1");
        System.out.println("answer: "+sArray.find_index_of_element(1));
        System.out.println("Data: "+sArray.get_current_data());
        
        System.out.println(">Find 4");
        System.out.println("answer: "+sArray.find_index_of_element(4));
        System.out.println("Data: "+sArray.get_current_data());
        
        System.out.println(">Find 8");
        System.out.println("answer: "+sArray.find_index_of_element(8));
        System.out.println("Data: "+sArray.get_current_data());
        
        System.out.println(">Find 100");
        System.out.println("answer: "+sArray.find_index_of_element(100));
        System.out.println("Data: "+sArray.get_current_data());
        
        System.out.println(">Find -100");
        System.out.println("answer: "+sArray.find_index_of_element(-100));
        System.out.println("Data: "+sArray.get_current_data());
        
        System.out.println(">Max");
        System.out.println("max = "+sArray.get_max_element());
        System.out.println("Data: "+sArray.get_current_data());
        
        System.out.println(">Min");
        System.out.println("min = "+sArray.get_min_element());
        System.out.println("Data: "+sArray.get_current_data());
        
        System.out.println(">Getting parameters differently");
        System.out.println("size = "+sArray.get_size());
        System.out.println("max_available_size = "+sArray.get_max_available_size());
        System.out.println("get_extention_multiplier = "+sArray.get_extention_multiplier());
        
        System.out.println(">Getting objects differently");
        System.out.println("data[0] = "+sArray.get_at(0));
        System.out.println("data[1] = "+sArray.get_at(1));
        System.out.println("data[3] = "+sArray.get_at(3));
        
        System.out.println(">DeleteAt 2");
        sArray.delete_element_at(2);
        System.out.println(sArray.get_current_state());
        System.out.println("Data: "+sArray.get_current_data());
        
        System.out.println(">DeleteAt 0");
        sArray.delete_element_at(0);
        System.out.println(sArray.get_current_state());
        System.out.println("Data: "+sArray.get_current_data());
        
        System.out.println(">DeleteAt <last_index>, last_index = "+(sArray.get_size()-1));
        sArray.delete_element_at(sArray.get_size()-1);
        System.out.println(sArray.get_current_state());
        System.out.println("Data: "+sArray.get_current_data());
        
        
        /*System.out.println(">");
        sArray
        System.out.println(sArray.get_current_state());
        System.out.println("Data: "+sArray.get_current_data());*/
    }
    
    public static void testing_bin_find_tree() {
        BinFindTree tree = new BinFindTree();
        int key;
        int answer;
        boolean answer_b;
        
        
        System.out.println(">test>Add 32");
        key = 32;
        tree.add_by_key(key);
        System.out.println(tree.get_data_simple());
        System.out.println(tree.get_data());
        
        System.out.println(">test>Add 64");
        key = 64;
        tree.add_by_key(key);
        System.out.println(tree.get_data_simple());        
        System.out.println(tree.get_data());
        
        System.out.println(">test>Add 48");
        key = 48;
        tree.add_by_key(key);
        System.out.println(tree.get_data_simple());        
        System.out.println(tree.get_data());
        
        System.out.println(">test>Add 24");
        key = 24;
        tree.add_by_key(key);
        System.out.println(tree.get_data_simple());        
        System.out.println(tree.get_data());
        
        System.out.println(">test>Add 16");
        key = 16;
        tree.add_by_key(key);
        System.out.println(tree.get_data_simple());        
        System.out.println(tree.get_data());
        
        System.out.println(">test>Add 19");
        key = 19;
        tree.add_by_key(key);
        System.out.println(tree.get_data_simple());        
        System.out.println(tree.get_data());
        
        System.out.println(">test>Add 1");
        key = 1;
        tree.add_by_key(key);
        System.out.println(tree.get_data_simple());        
        System.out.println(tree.get_data());
        
        System.out.println(">test>Add 3");
        key = 3;
        tree.add_by_key(key);
        System.out.println(tree.get_data_simple());        
        System.out.println(tree.get_data());
        
        System.out.println(">test>Add 16");
        key = 16;
        tree.add_by_key(key);
        System.out.println(tree.get_data_simple());        
        System.out.println(tree.get_data());
        
        System.out.println(">test>Add 11");
        key = 11;
        tree.add_by_key(key);
        System.out.println(tree.get_data_simple());        
        System.out.println(tree.get_data());
        
        System.out.println(">test>Add 18");
        key = 18;
        tree.add_by_key(key);
        System.out.println(tree.get_data_simple());        
        System.out.println(tree.get_data());
        
        System.out.println(">test>Find 1");
        key = 1;
        answer_b = tree.find_by_key(key) != false;
        System.out.println("exist? "+answer_b);
        System.out.println(tree.get_data_simple());        
        System.out.println(tree.get_data());
        
        System.out.println(">test>Find 64");
        key = 64;
        answer_b = tree.find_by_key(key) != false;
        System.out.println("exist? "+answer_b);
        System.out.println(tree.get_data_simple());        
        System.out.println(tree.get_data());
        
        System.out.println(">test>Find 12");
        key = 12;
        answer_b = tree.find_by_key(key) != false;
        System.out.println("exist? "+answer_b);
        System.out.println(tree.get_data_simple());        
        System.out.println(tree.get_data());
        
        System.out.println(">test>Del 14");
        key = 14;
        answer_b = tree.delete_by_key(key);
        System.out.println("answer: "+answer_b);
        System.out.println(tree.get_data_simple());        
        System.out.println(tree.get_data());
        
        System.out.println(">test>Del 32");
        key = 32;
        answer_b = tree.delete_by_key(key);
        System.out.println("answer: "+answer_b);
        System.out.println(tree.get_data_simple());        
        System.out.println(tree.get_data());
        
        System.out.println(">test>Del 1");
        key = 1;
        answer_b = tree.delete_by_key(key);
        System.out.println("answer: "+answer_b);
        System.out.println(tree.get_data_simple());        
        System.out.println(tree.get_data());
        
        
        /*
        
        System.out.println(">test>Find ");
        key = ;
        answer_b = tree.find_by_key(key) != null;
        System.out.println("exist? "+answer_b);
        System.out.println(tree.get_data());
        */
        
        /*
        
        System.out.println(">test>Depth");
        answer = tree.get_depth();
        System.out.println("answer: "+answer);
        System.out.println(tree.get_data());*/
        
        /*
        
        System.out.println(">test>Add ");
        key = ;
        tree.add_by_key(key);
        System.out.println(tree.get_data());*/
        
        /*
        
        System.out.println(">test>Del ");
        key = ;
        answer_b = tree.delete_by_key(key);
        System.out.println("answer: "+answer_b);
        System.out.println(tree.get_data());*/
        
        
        /*
        //a = tree.get_depth();
        tree.add_by_key(32);
        //a = tree.get_depth();
        tree.add_by_key(33);
        //a = tree.get_depth();
        tree.add_by_key(31);
        //a = tree.get_depth();
        tree.add_by_key(34);
        //a = tree.get_depth();
        tree.add_by_key(35);
        a = tree.get_depth();
        int b =1;
        
        System.out.println(tree.get_data());*/
    }
    
    public static void testing_bin_find_tree_2() {
        BinFindTree tree = new BinFindTree();
        int key;
        int answer;
        boolean answer_b;
        
        System.out.println(tree.get_data_simple());
        System.out.println(tree.get_data());
        
        System.out.println(">test>Add 5, 3, 7, 2, 4, 9, 8");
        tree.add_by_key(5);
        tree.add_by_key(3);
        tree.add_by_key(7);
        tree.add_by_key(2);
        tree.add_by_key(4);
        tree.add_by_key(9);
        tree.add_by_key(8);
        System.out.println(tree.get_data_simple());
        System.out.println(tree.get_data());
    }
}
