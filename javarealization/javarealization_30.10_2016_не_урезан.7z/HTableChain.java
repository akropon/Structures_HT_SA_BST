/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javarealization;

/**
 *
 * @author Akropon
 */
public class HTableChain {
    protected HChain[] table;
    protected int num_of_items;
    protected int table_size;
    //protected int extention_multiplier;
    
    protected int hFunc(int argument) {
        return argument % table_size;
    }
    
    public HTableChain(int table_size/*, int extention_multiplier*/) {
        if ( table_size < 1 ) table_size = 1;
        this.table_size = table_size;
        //this.extention_multiplier = extention_multiplier;
        this.num_of_items = 0;
        this.table = new HChain[table_size];
        for (int i=0; i<table_size; i++)
            this.table[i] = null;
    }
    
    public boolean add_by_key(int key) {
        /*if (num_of_items == table_size) {
            int prev_table_size = table_size;
            HChain[] prev_table = table;
            
            table_size *= extention_multiplier;
            table = new HChain[table_size];
            
            HChain cur_chain;
            HChain next_chain;
            int target_index;
            for ( int i=0; i<prev_table_size; i++ ) {
                cur_chain = prev_table[i];
                while ( cur_chain != null ) {
                    next_chain = cur_chain.next;
                    
                    target_index = hFunc(cur_chain.key);
                    cur_chain.next = table[target_index];
                    table[target_index] = cur_chain;
                    
                    cur_chain = next_chain;
                }
            }
        }*/
        
        if ( key<0 ) return false;
        
        int target_index = hFunc(key);
        HChain new_chain = new HChain(key, table[target_index]);
        table[target_index] = new_chain;
        num_of_items++;
        return true;
    }
    
    public boolean delete_by_key(int key) {
        if ( key < 0 ) return false;
        int target_index = hFunc(key);
        if (table[target_index] == null)  return false;
        if (table[target_index].key == key) {
            table[target_index] = table[target_index].next;
            num_of_items--;
            return true;
        }
        HChain cur_chain = table[target_index];
        while(true) {
            if (cur_chain.next == null)  return false;
            if (cur_chain.next.key == key) { 
                cur_chain.next = cur_chain.next.next;
                num_of_items--;
                return true;
            }
            cur_chain = cur_chain.next;
        }
    }
    
    public boolean find_by_key(int key) {
        if ( key < 0 ) return false;
        HChain cur_chain = table[hFunc(key)];
        while(true) {
            if (cur_chain == null)  return false;
            if (cur_chain.key == key)
                return true;
            cur_chain = cur_chain.next;
        }
    }
    
    public int get_max() {
        HChain max_chain = null;
        HChain cur_chain;
        for ( int i=0; i<table_size; i++ ) {
            cur_chain = table[i];
            while ( cur_chain != null ) {
                if ( max_chain == null ) max_chain = cur_chain;
                else 
                    if (cur_chain.key > max_chain.key) 
                        max_chain = cur_chain;
                cur_chain = cur_chain.next;
            }
        }
        return (max_chain!=null) ? max_chain.key : -1;
    }
    
    public int get_min() {
        HChain min_chain = null;
        HChain cur_chain;
        for ( int i=0; i<table_size; i++ ) {
            cur_chain = table[i];
            while ( cur_chain != null ) {
                if ( min_chain == null ) min_chain = cur_chain;
                else 
                    if (min_chain.key < min_chain.key) 
                        min_chain = cur_chain;
                cur_chain = cur_chain.next;
            }
        }
        return (min_chain!=null) ? min_chain.key : -1;
    }
    
    public String get_current_data() {
        StringBuilder stringB = new StringBuilder();
        HChain cur_chain;
        for ( int i=0; i<table_size; i++ ) {
            stringB.append("  [");
            stringB.append(i);
            stringB.append("] -> ");
            cur_chain = table[i];
            while ( true ) {
                if ( cur_chain == null ) {
                    stringB.append("NULL\n");
                    break;
                }
                else {
                    stringB.append(cur_chain.key);
                    stringB.append(" -> ");
                    cur_chain = cur_chain.next;
                }
            }
        }
        return stringB.toString();
    }
    
    public String get_current_data_simple() {
        StringBuilder stringB = new StringBuilder();
        HChain cur_chain;
        for ( int i=0; i<table_size; i++ ) {
            stringB.append("[");
            stringB.append(i);
            stringB.append("]-");
            cur_chain = table[i];
            while ( true ) {
                if ( cur_chain == null ) {
                    stringB.append("N ");
                    break;
                }
                else {
                    stringB.append(cur_chain.key);
                    stringB.append("-");
                    cur_chain = cur_chain.next;
                }
            }
        }
        return stringB.toString();
    }
    
    public String get_current_state() {
        return "num_of_items = "+num_of_items+" || table_size = "+table_size;
    }
    
    public static class HChain {
        public int key;
        public HChain next;
        
        public HChain() {
            key = -1;
            next = null;
        }
        
        public HChain(int key) {
            this.key = key;
            next = null;
        }
        
        public HChain(int key, HChain next) {
            this.key = key;
            this.next = next;
        }
    }
}
