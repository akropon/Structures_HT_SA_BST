/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javarealization;

/** 
 * Двоичное дерево поиска.
 * 
 * Структура, содержащая в себе неотрицательные числа типа int.
 * Реализация двоичного дерева поиска по правилу ( левый сын меньше отца ).
 * Поддерживает возможность повтора элементов (т.е. в структуре могут 
 * одновременно присутствовать элементы с совпадающими значениями).
 * Присутствует внутреклассовая реализация узла дерева "Node".
 * Значение и ключ в данной реализации совпадают, поэтому отдельного поля для 
 * значения выделяться не будет.
 *
 * @author Akropon
 */
public class BinFindTree {
    protected Node root; // корень дерева
    
    public BinFindTree() {
        root = null;
    }
    
    public boolean find_by_key(int key) {
        if ( key < 0 ) return false;
        
        if (root == null) {
            return false;
        }
        
        Node node = root;
        while (true) {
            if ( key == node.key )
                return true;
            if ( key > node.key )
                if ( node.right == null )
                    return true;
                else 
                    node = node.right;
            else // key < node.key
                if ( node.left == null )
                    return true;
                else 
                    node = node.left;
        }
    }
    
    public boolean add_by_key(int key) {
        if (key < 0) return false;
        
        if (root == null) {
            root = new Node(key);
            return true;
        }
        
        Node node = root;
        while (true) {
            if ( key >= node.key ) {
                if ( node.right == null ) {
                    node.right = new Node(key, node);
                    return true;
                }
                else 
                    node = node.right;
            } else { // key < node.key
                if ( node.left == null ) {
                    node.left = new Node(key, node);
                    return true;
                }
                else 
                    node = node.left;
            }
        }
    }
    
    public boolean delete_by_key(int key) {
        if ( key < 0 ) return false;
        
        if (root == null) {
            return false;
        }
        
        Node node = root;
        while (true) {
            if ( key == node.key ) {
                if ( node.left == null && node.right == null ) {
                    if ( node == root ) {
                        root = null;
                        return true;
                    }
                    // node != root
                    if ( node == node.father.right )
                        node.father.right = null;
                    else
                        node.father.left = null;
                    return true;
                }
                if ( node.left != null && node.right == null) {
                    if ( node == root ) {
                        root = node.left;
                        return true;
                    }
                    // node != root
                    if ( node == node.father.right ) {
                        node.father.right = node.left;
                        node.left.father = node.father;
                    }
                    else {
                        node.father.left = node.left;
                        node.left.father = node.father;
                    }
                    return true;
                }
                if ( node.left == null && node.right != null) {
                    if ( node == root ) {
                        root = node.right;
                        return true;
                    }
                    // node != root
                    if ( node == node.father.right ) {
                        node.father.right = node.right;
                        node.right.father = node.father;
                    }
                    else {
                        node.father.left = node.right;
                        node.right.father = node.father;
                    }
                    return true;
                }
                
                // node.left != null && node.right != null
                Node rstmn = node.right; // rstmn - RightSonTree-Min-Node
                while(rstmn.left != null) 
                    rstmn = rstmn.left;
                rstmn.father.right = rstmn.right;
                node.key = rstmn.key;
                return true;
            }
            if ( key > node.key )
                if ( node.right == null )
                    return false;
                else 
                    node = node.right;
            else // key < node.key
                if ( node.left == null )
                    return false;
                else 
                    node = node.left;
        }
    }
    
    public int get_min() {
        if ( root == null ) return -1;
        Node node = root;
        while ( node.left != null )
            node = node.left;
        return node.key;
    }
    
    public int get_max() {
        if ( root == null ) return -1;
        Node node = root;
        while ( node.right != null )
            node = node.right;
        return node.key;
    }
    
    public int get_depth() {
        if ( root == null ) return 0;
        
        int max_depth = 0;
        int cur_depth = 0;
        Node cur_node = root;
        byte id_from = 0; // 0-пришел от отца, 1-пришел от левого сына, 2-от правого сына
        while(true) {
            switch ( id_from ) {
                case 0:
                    cur_depth++;
                    if (cur_depth > max_depth)
                        max_depth = cur_depth;
                    if (cur_node.left!=null) {
                        cur_node = cur_node.left;
                        //id_from=0;
                    }
                    else {
                        id_from = 1;
                        cur_depth++;
                    }
                    break;
                case 1:
                    cur_depth--;
                    if (cur_node.right!=null) {
                        cur_node = cur_node.right;
                        id_from=0;
                    }
                    else {
                        id_from = 2;
                        cur_depth++;
                    }
                    break;
                case 2:
                    cur_depth--;
                    if ( cur_node.father == null ) return max_depth;
                    if ( cur_node.father.left == cur_node )
                        id_from = 1;
                    else
                        id_from = 2;
                    cur_node = cur_node.father;
                    break;
                default: return -1; // ошибка
            }
        }
        
        /*
        // стэк для записи информации по обходу дерева в глубину. 
        // 0-ни один сын не просморен, 1-был выполнен вход в просмотр левого сына 
        // 2-был выполнен вход в просмотр правого сына
        java.util.ArrayList<Integer> stack = new java.util.ArrayList<>();
        int max_depth = 0;
        int cur_depth = 1;
        Node cur_node = root;
        stack.add(0);
        while (stack.size() > 0 ) {
            switch (stack.get(stack.size()-1) ) {
                case 0:
                    
                    
                case 1:
                    
                    
                case 2:
            }
        } */
        
    }
    
    
    
    public String get_data() {
        if ( root == null ) return "tree is empty";
        // размер поля под узел БЕЗ УЧЕТА ПРОБЕЛА
        int item_size = (int)Math.floor(Math.log10(get_max()))+1; 
        // глубина дерева
        int depth = get_depth();
        // макс. возможное кол-во элементов на уровне
        int max_num_of_nodes_in_level = (int)Math.pow(2, depth-1);
        int max_string_length = max_num_of_nodes_in_level * (item_size+1);
        
        StringBuilder stringCommon = new StringBuilder();
        
        Node[] level_nodes = new Node[max_num_of_nodes_in_level];
        level_nodes[0] = root;
        int cur_level =  1;
        int nodes_at_cur_level = 1;
        // Рассмотрим каждый уровень
        while(cur_level <= depth) {
            StringBuilder stringFirst = new StringBuilder(); // Строка с элементом
            StringBuilder stringSecond = new StringBuilder(); // Строка с "палками"
            
            int cur_item_size = max_string_length/nodes_at_cur_level;
            // Рассмотрим участок строки для каждого элемента
            for (int i=0; i<nodes_at_cur_level; i++) { 
                // пустой узел?
                if (level_nodes[i] == null ) {
                    for ( int j=0; j<cur_item_size; j++) {
                        stringFirst.append(' ');
                        stringSecond.append(' ');
                    }
                } else { // Узел не пустой!
                    int key_str_size = (int)Math.floor(Math.log10(level_nodes[i].key))+1;
                
                    stringFirst.append(level_nodes[i].key);
                    if (cur_level != depth) {
                        if (level_nodes[i].left != null) 
                            stringSecond.append('|');
                        else 
                            stringSecond.append(' ');
                    }

                    if (cur_level != depth) 
                        if (level_nodes[i].right != null) {
                            for ( int j=key_str_size; j<cur_item_size/2; j++)
                                stringFirst.append('-');
                        } else {
                            for ( int j=key_str_size; j<cur_item_size/2; j++)
                                stringFirst.append(' ');
                        }
                    else 
                        for ( int j=key_str_size; j<cur_item_size; j++)
                            stringFirst.append(' ');
                    if (cur_level != depth) 
                        for ( int j=1; j<cur_item_size/2; j++)
                            stringSecond.append(' ');

                    if (cur_level != depth) {
                        if (level_nodes[i].right != null) 
                            stringFirst.append('-');
                        else
                            stringFirst.append(' ');
                    }
                    if (cur_level != depth) {
                        if (level_nodes[i].right != null)
                            stringSecond.append('|');
                        else
                            stringSecond.append(' ');
                    }

                    if (cur_level != depth) 
                        for ( int j=cur_item_size/2+1; j<cur_item_size; j++) {
                            stringFirst.append(' ');
                            stringSecond.append(' ');
                        }
                }
            }
            // Восстановим двойную строку для уровня
            stringCommon.append(stringFirst);
            stringCommon.append("\n");
            if (cur_level != depth) stringCommon.append(stringSecond);
            if (cur_level != depth) stringCommon.append("\n");
            
            // Есть ли след уровень?
            if ( cur_level == depth ) break; // нет. Хватит рисовать.
            // Переходим на след уровень
            cur_level++;
            nodes_at_cur_level *= 2;
            // Соберем данные по элементам для след уровня, используя пред
            for ( int i=nodes_at_cur_level/2-1; i>=0; i--){
                if ( level_nodes[i] != null ) {
                    level_nodes[2*i+1] = level_nodes[i].right;
                    level_nodes[2*i]   = level_nodes[i].left;
                }
                else {
                    level_nodes[2*i+1] = null;
                    level_nodes[2*i]   = null;
                }
            }
        }
        return stringCommon.toString();
    }
    
    public String get_data_simple() {
        StringBuilder stringB = new StringBuilder();
        if ( root == null ) return "tree is empty";
        
        // Выполним прямой обход дерева.
        Node cur_node = root;
        byte id_from = 0; // 0-пришел от отца, 1-пришел от левого сына, 2-от правого сына
        while(true) {
            switch ( id_from ) {
                case 0:
                    stringB.append(cur_node.key);
                    if (cur_node.left!=null) {
                        stringB.append("L");
                        cur_node = cur_node.left;
                        //id_from=0;
                    }
                    else {
                        id_from = 1;
                    }
                    break;
                case 1:
                    if (cur_node.right!=null) {
                        stringB.append("R");
                        cur_node = cur_node.right;
                        id_from=0;
                    }
                    else {
                        id_from = 2;
                    }
                    break;
                case 2:
                    if ( cur_node.father == null ) return stringB.toString();
                    if ( cur_node.father.left == cur_node )
                        id_from = 1;
                    else
                        id_from = 2;
                    stringB.append("P");
                    cur_node = cur_node.father;
                    break;
                default: return "error"; // ошибка(которой быть не должно)
            }
        }
    }
    
    
    /** Узел для двоичного дерева поиска BinFindTree
     * 
     * @author Akropon
     */
    public static class Node {
        public Node father; // Отец
        public Node left;  // Левый сын
        public Node right;  // Правый сын
        public int key;  // ключ(он же значение)
        
        /** Конструктор
         * 
         * Создает узел со всеми "нулевыми" полями.
         */
        public Node() {
            father = left = right = null; // нулевые указатели
            key = -1;  // ~пустой ключ
        }
        
        /** Конструктор
         * 
         * Создает узел с заданным ключем и "нулевыми" указателями.
         * 
         * @param key - ключ
         */
        public Node(int key) {
            father = left = right = null;
            this.key = key;  
        }
        
        /** Конструктор
         * 
         * Создает узел с заданным ключем, ссылкой на отца и 
         * нулевыми ссылками на сыновей
         * 
         * @param key - ключ
         * @param father - отец
         */
        public Node(int key, Node father) {
            left = right = null;
            this.father = father;
            this.key = key;  
        }
    }
}