/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javarealization;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author Akropon
 */
public class Executor {
    protected HTableChain _ht;
    protected SortedArray _sa;
    protected BinFindTree _bft;
    protected int _mode;
    protected FileWriter out;
    protected BufferedReader in;
    
    protected static final String NL = System.getProperty("line.separator");
    
    protected static final int MODE_NONE = 0;
    protected static final int MODE_HT = 1;
    protected static final int MODE_SA = 2;
    protected static final int MODE_BFT = 3;
    
    protected static final String CMD_MODE = "mode";
    protected static final String CMD_NEW = "new";
    protected static final String CMD_ADD = "add";
    protected static final String CMD_DEL = "del";
    protected static final String CMD_FIND = "find";
    protected static final String CMD_MIN = "min";
    protected static final String CMD_MAX = "max";
    protected static final String CMD_DATA = "data";
    protected static final String CMD_STATE = "state";
    protected static final String CMD_DATASIMPLE = "datasimple";
    protected static final String CMD_DEPTH = "depth";
    protected static final String CMD_AT = "at";
    protected static final String ARG_HT = "ht";
    protected static final String ARG_SA = "sa";
    protected static final String ARG_BFT = "bft";
    
    public Executor () {
        _ht = null;
        _sa = null;
        _bft = null;
        _mode = MODE_NONE;
    }
    
    public void exec(String input_file_path, String output_file_path) {
        
        if (!opening_files(input_file_path, output_file_path)) return;
        
        executing_commands();
        
        closing_files();
    }
    
    protected boolean opening_files(String input_file_path, String output_file_path) {
        
        try {
            out = new FileWriter(output_file_path);
        } catch (IOException e) {
            System.out.println("Error opening output-file:\n"+e.toString()+"\nProgram is interrupted.");
            return false;
        }
        
        try {
            in = new BufferedReader(new FileReader(input_file_path));
        } catch(IOException e) {
            System.out.println("Error opening input-file:\n"+e.toString()+"\nProgram is interrupted.");
            return false; 
        }
        
        return true;
    }
    
    protected boolean closing_files() {
        boolean success = true;      
        
        try {
            in.close();
        } catch (IOException e) {
            System.out.println("Error closing input-file:\n"+e.toString()+"\n");
            success = false;
        }
        
        try {
            out.close();
        } catch (IOException e) {
            System.out.println("Error closing output-file:\n"+e.toString()+"\n");
            success = false;
        }
        
        return success;
    }

    protected boolean executing_commands() {
        int num_of_line = -1;
        String line;
        String[] words;
        int int_arg_0;
        int int_arg_1;
        int comment_start_index;
        
        try {
            
            //while ( (line = read_new_line(in)) != null){
            while ( (line = in.readLine()) != null){
                num_of_line++;
                if ( (comment_start_index = line.indexOf("//")) != -1 )
                    line = line.substring(0, comment_start_index);
                if ( line.length() == 0 ) continue;
                out.write(">>"+line+NL);
                if ( line.length() == 0 ) continue;
                words = line.split(" ");
                if ( words.length == 0 ) continue;
                
                
                if ( words[0].compareToIgnoreCase(CMD_ADD) == 0) {
                    if ( words.length < 2 ) {
                        out.write("Error. Not found argument in command \""
                            +words[0]+"\"" + NL
                            + "in line: "+num_of_line+NL+"Aborting executing commands..."+NL);
                        return false;
                    }
                    
                    try {
                        int_arg_0 = Integer.parseInt(words[1]);
                    } catch (NumberFormatException exc) {
                        out.write("Error. Illegal argument \""
                            +words[1]+"\" in command \""+line+"\""
                            + NL + "in line: "+num_of_line+NL+"Aborting executing commands..."+NL);
                        return false;
                    }
                    
                    switch(_mode) {
                        case MODE_HT:
                            if ( _ht == null ) {
                                out.write("Error. HTable wasn't been created. "
                                    +NL+"Aborting executing commands..."+NL);
                                return false;
                            }
                            out.write("Answer: "+_ht.add_by_key(int_arg_0)+NL);
                            break;
                        case MODE_SA:
                            if ( _sa == null ) {
                                out.write("Error. SArray wasn't been created. "
                                    +NL+"Aborting executing commands..."+NL);
                                return false;
                            }
                            out.write("Answer: "+_sa.add_element(int_arg_0)+NL);
                            break;
                        case MODE_BFT:
                            if ( _bft == null ) {
                                out.write("Error. BFTree wasn't been created. "
                                    +NL+"Aborting executing commands..."+NL);
                                return false;
                            }
                            out.write("Answer: "+_bft.add_by_key(int_arg_0)+NL);
                            break;
                        case MODE_NONE:
                            out.write("Error. Mode was not chosen."
                                +NL+"Aborting executing commands...");
                            break;
                        default:
                            out.write("Error. Unexpected value of _mode = "+_mode
                                +NL+"Aborting executing commands..."+NL);
                            break;
                    }
                    
                    
                } else if (words[0].compareToIgnoreCase(CMD_FIND) == 0) {
                    if ( words.length < 2 ) {
                        out.write("Error. Not found argument in command \""
                            +words[0]+"\"" + NL
                            + "in line: "+num_of_line+NL+"Aborting executing commands..."+NL);
                        return false;
                    }
                    
                    try {
                        int_arg_0 = Integer.parseInt(words[1]);
                    } catch (NumberFormatException exc) {
                        out.write("Error. Illegal argument \""
                            +words[1]+"\" in command \""+line+"\""
                            + NL + "in line: "+num_of_line+NL+"Aborting executing commands..."+NL);
                        return false;
                    }
                    
                    switch(_mode) {
                        case MODE_HT:
                            if ( _ht == null ) {
                                out.write("Error. HTable wasn't been created. "
                                    +NL+"Aborting executing commands..."+NL);
                                return false;
                            }
                            if (_ht.find_by_key(int_arg_0)!=false) 
                                out.write("FOUND."+NL);
                            else
                                out.write("NOT FOUND."+NL);
                            break;
                        case MODE_SA:
                            if ( _sa == null ) {
                                out.write("Error. SArray wasn't been created. "
                                    +NL+"Aborting executing commands..."+NL);
                                return false;
                            }
                            out.write("Answer: "+_sa.find_index_of_element(int_arg_0)+NL);
                            break;
                        case MODE_BFT:
                            if ( _bft == null ) {
                                out.write("Error. BFTree wasn't been created. "
                                    +NL+"Aborting executing commands..."+NL);
                                return false;
                            }
                            if (_bft.find_by_key(int_arg_0)!=false) 
                                out.write("FOUND."+NL);
                            else
                                out.write("NOT FOUND."+NL);
                            break;
                        case MODE_NONE:
                            out.write("Error. Mode was not chosen."
                                +NL+"Aborting executing commands...");
                            break;
                        default:
                            out.write("Error. Unexpected value of _mode = "+_mode
                                +NL+"Aborting executing commands..."+NL);
                            break;
                    }
                    
                    
                } else if (words[0].compareToIgnoreCase(CMD_DEL) == 0) {
                    if ( words.length < 2 ) {
                        out.write("Error. Not found argument in command \""
                            +words[0]+"\"" + NL
                            + "in line: "+num_of_line+NL+"Aborting executing commands..."+NL);
                        return false;
                    }
                    
                    try {
                        int_arg_0 = Integer.parseInt(words[1]);
                    } catch (NumberFormatException exc) {
                        out.write("Error. Illegal argument \""
                            +words[1]+"\" in command \""+line+"\""
                            + NL + "in line: "+num_of_line+NL+"Aborting executing commands..."+NL);
                        return false;
                    }
                    
                    switch(_mode) {
                        case MODE_HT:
                            if ( _ht == null ) {
                                out.write("Error. HTable wasn't been created. "
                                    +NL+"Aborting executing commands..."+NL);
                                return false;
                            }
                            out.write("Answer: "+_ht.delete_by_key(int_arg_0)+NL);
                            break;
                        case MODE_SA:
                            if ( _sa == null ) {
                                out.write("Error. SArray wasn't been created. "
                                    +NL+"Aborting executing commands..."+NL);
                                return false;
                            }
                            _sa.delete_element_at(int_arg_0);
                            break;
                        case MODE_BFT:
                            if ( _bft == null ) {
                                out.write("Error. BFTree wasn't been created. "
                                    +NL+"Aborting executing commands..."+NL);
                                return false;
                            }
                            out.write("Answer: "+_bft.delete_by_key(int_arg_0)+NL);
                            break;
                        case MODE_NONE:
                            out.write("Error. Mode was not chosen."
                                +NL+"Aborting executing commands...");
                            break;
                        default:
                            out.write("Error. Unexpected value of _mode = "+_mode
                                +NL+"Aborting executing commands..."+NL);
                            break;
                    }
                    
                    
                } else if (words[0].compareToIgnoreCase(CMD_DATA) == 0) {
                    switch(_mode) {
                        case MODE_HT:
                            if ( _ht == null ) {
                                out.write("Error. HTable wasn't been created. "
                                    +NL+"Aborting executing commands..."+NL);
                                return false;
                            }
                            out.write(_ht.get_current_data());
                            out.write(NL);
                            break;
                            
                        case MODE_SA:
                            if ( _sa == null ) {
                                out.write("Error. SArray wasn't been created. "
                                    +NL+"Aborting executing commands..."+NL);
                                return false;
                            }
                            out.write(_sa.get_current_data());
                            out.write(NL);
                            break;
                            
                        case MODE_BFT:
                            if ( _bft == null ) {
                                out.write("Error. BFTree wasn't been created. "
                                    +NL+"Aborting executing commands..."+NL);
                                return false;
                            }
                            out.write(_bft.get_data());
                            out.write(NL);
                            break;
                            
                        case MODE_NONE:
                            out.write("Error. Mode was not chosen."
                                +NL+"Aborting executing commands...");
                            break;
                            
                        default:
                            out.write("Error. Unexpected value of _mode = "+_mode
                                +NL+"Aborting executing commands..."+NL);
                            break;
                    }
                    
                    
                } else if (words[0].compareToIgnoreCase(CMD_STATE) == 0) {
                    switch(_mode) {
                        case MODE_HT:
                            if ( _ht == null ) {
                                out.write("Error. HTable wasn't been created. "
                                    +NL+"Aborting executing commands..."+NL);
                                return false;
                            }
                            out.write(_ht.get_current_state());
                            out.write(NL);
                            break;
                            
                        case MODE_SA:
                            if ( _sa == null ) {
                                out.write("Error. SArray wasn't been created. "
                                    +NL+"Aborting executing commands..."+NL);
                                return false;
                            }
                            out.write(_sa.get_current_state());
                            out.write(NL);
                            break;
                            
                        case MODE_BFT:
                            if ( _bft == null ) {
                                out.write("Error. BFTree wasn't been created. "
                                    +NL+"Aborting executing commands..."+NL);
                                return false;
                            }
                            out.write("Error. No such information for BFTree. ");
                            out.write(NL);
                            break;
                            
                        case MODE_NONE:
                            out.write("Error. Mode was not chosen."
                                +NL+"Aborting executing commands...");
                            break;
                            
                        default:
                            out.write("Error. Unexpected value of _mode = "+_mode
                                +NL+"Aborting executing commands..."+NL);
                            break;
                    }
                    
                    
                } else if (words[0].compareToIgnoreCase(CMD_DATASIMPLE) == 0) {
                    switch(_mode) {
                        case MODE_HT:
                            if ( _ht == null ) {
                                out.write("Error. HTable wasn't been created. "
                                    +NL+"Aborting executing commands..."+NL);
                                return false;
                            }
                            out.write(_ht.get_current_data_simple());
                            out.write(NL);
                            break;
                            
                        case MODE_SA:
                            if ( _sa == null ) {
                                out.write("Error. SArray wasn't been created. "
                                    +NL+"Aborting executing commands..."+NL);
                                return false;
                            }
                            out.write("Error. No such information for SArray. ");
                            out.write(NL);
                            break;
                            
                        case MODE_BFT:
                            if ( _bft == null ) {
                                out.write("Error. BFTree wasn't been created. "
                                    +NL+"Aborting executing commands..."+NL);
                                return false;
                            }
                            out.write(_bft.get_data_simple());
                            out.write(NL);
                            break;
                            
                        case MODE_NONE:
                            out.write("Error. Mode was not chosen."
                                +NL+"Aborting executing commands...");
                            break;
                            
                        default:
                            out.write("Error. Unexpected value of _mode = "+_mode
                                +NL+"Aborting executing commands..."+NL);
                            break;
                    }
                    
                    
                } else if (words[0].compareToIgnoreCase(CMD_MIN) == 0) {
                    switch(_mode) {
                        case MODE_HT:
                            if ( _ht == null ) {
                                out.write("Error. HTable wasn't been created. "
                                    +NL+"Aborting executing commands..."+NL);
                                return false;
                            }
                            out.write(_ht.get_min());
                            out.write(NL);
                            break;
                            
                        case MODE_SA:
                            if ( _sa == null ) {
                                out.write("Error. SArray wasn't been created. "
                                    +NL+"Aborting executing commands..."+NL);
                                return false;
                            }
                            out.write(_sa.get_min_element());
                            out.write(NL);
                            break;
                            
                        case MODE_BFT:
                            if ( _bft == null ) {
                                out.write("Error. BFTree wasn't been created. "
                                    +NL+"Aborting executing commands..."+NL);
                                return false;
                            }
                            out.write(_bft.get_max());
                            out.write(NL);
                            break;
                            
                        case MODE_NONE:
                            out.write("Error. Mode was not chosen."
                                +NL+"Aborting executing commands...");
                            break;
                            
                        default:
                            out.write("Error. Unexpected value of _mode = "+_mode
                                +NL+"Aborting executing commands..."+NL);
                            break;
                    }
                    
                    
                } else if (words[0].compareToIgnoreCase(CMD_MAX) == 0) {
                    switch(_mode) {
                        case MODE_HT:
                            if ( _ht == null ) {
                                out.write("Error. HTable wasn't been created. "
                                    +NL+"Aborting executing commands..."+NL);
                                return false;
                            }
                            out.write(_ht.get_max());
                            out.write(NL);
                            break;
                            
                        case MODE_SA:
                            if ( _sa == null ) {
                                out.write("Error. SArray wasn't been created. "
                                    +NL+"Aborting executing commands..."+NL);
                                return false;
                            }
                            out.write(_sa.get_max_element());
                            out.write(NL);
                            break;
                            
                        case MODE_BFT:
                            if ( _bft == null ) {
                                out.write("Error. BFTree wasn't been created. "
                                    +NL+"Aborting executing commands..."+NL);
                                return false;
                            }
                            out.write(_bft.get_max());
                            out.write(NL);
                            break;
                            
                        case MODE_NONE:
                            out.write("Error. Mode was not chosen."
                                +NL+"Aborting executing commands...");
                            break;
                            
                        default:
                            out.write("Error. Unexpected value of _mode = "+_mode
                                +NL+"Aborting executing commands..."+NL);
                            break;
                    }
                    
                    
                } else if (words[0].compareToIgnoreCase(CMD_NEW) == 0) {
                    switch(_mode) {
                        case MODE_HT:
                            if ( words.length < 2 ) {
                                out.write("Error. Not found anought arguments in command \""
                                    +words[0]+"\"" + NL
                                    + "in line: "+num_of_line+NL+"Aborting executing commands..."+NL);
                                return false;
                            }
                            try {
                                int_arg_0 = Integer.parseInt(words[1]);
                            } catch (NumberFormatException exc) {
                                out.write("Error. Illegal argument \""
                                    +words[1]+"\" in command \""+line+"\""
                                    + NL + "in line: "+num_of_line+NL+"Aborting executing commands..."+NL);
                                return false;
                            }
                            _ht = new HTableChain(int_arg_0);
                            break;
                            
                        case MODE_SA:
                            if ( words.length < 3 ) {
                                out.write("Error. Not found anought arguments in command \""
                                    +words[0]+"\"" + NL
                                    + "in line: "+num_of_line+NL+"Aborting executing commands..."+NL);
                                return false;
                            }
                            try {
                                int_arg_0 = Integer.parseInt(words[1]);
                            } catch (NumberFormatException exc) {
                                out.write("Error. Illegal argument \""
                                    +words[1]+"\" in command \""+line+"\""
                                    + NL + "in line: "+num_of_line+NL+"Aborting executing commands..."+NL);
                                return false;
                            }
                            try {
                                int_arg_1 = Integer.parseInt(words[2]);
                            } catch (NumberFormatException exc) {
                                out.write("Error. Illegal argument \""
                                    +words[2]+"\" in command \""+line+"\""
                                    + NL + "in line: "+num_of_line+NL+"Aborting executing commands..."+NL);
                                return false;
                            }
                            _sa = new SortedArray(int_arg_0, int_arg_1);
                            break;
                            
                        case MODE_BFT:
                            _bft = new BinFindTree();
                            break;
                            
                        case MODE_NONE:
                            out.write("Error. Mode was not chosen."
                                +NL+"Aborting executing commands...");
                            break;
                            
                        default:
                            out.write("Error. Unexpected value of _mode = "+_mode
                                +NL+"Aborting executing commands..."+NL);
                            break;
                    }
                    
                    
                } else if (words[0].compareToIgnoreCase(CMD_MODE) == 0) {
                    if ( words.length < 2) {
                        out.write("Error. Not found argument in command \""
                            +words[0]+"\""
                            + NL + "in line: "+num_of_line+NL+"Aborting executing commands..."+NL);
                        return false;
                    } else if ( words[1].compareToIgnoreCase(ARG_HT) == 0) {
                        _mode = MODE_HT;
                    } else if (words[1].compareToIgnoreCase(ARG_SA) == 0) {
                        _mode = MODE_SA;
                    } else if (words[1].compareToIgnoreCase(ARG_BFT) == 0) {
                        _mode = MODE_BFT;
                    } else {
                        out.write("Error. Illegal argument \""
                            +words[1]+"\" in command \""+line+"\""
                            + NL + "in line: "+num_of_line+NL+"Aborting executing commands..."+NL);
                        return false;
                    }
                    
                    
                } else if (words[0].compareToIgnoreCase(CMD_DEPTH) == 0) {
                    switch(_mode) {
                        case MODE_HT:
                            if ( _ht == null ) {
                                out.write("Error. HTable wasn't been created. "
                                    +NL+"Aborting executing commands..."+NL);
                                return false;
                            }
                            out.write("Error. No such information for HTable. ");
                            out.write(NL);
                            break;
                            
                        case MODE_SA:
                            if ( _sa == null ) {
                                out.write("Error. SArray wasn't been created. "
                                    +NL+"Aborting executing commands..."+NL);
                                return false;
                            }
                            out.write("Error. No such information for SArray. ");
                            out.write(NL);
                            break;
                            
                        case MODE_BFT:
                            if ( _bft == null ) {
                                out.write("Error. BFTree wasn't been created. "
                                    +NL+"Aborting executing commands..."+NL);
                                return false;
                            }
                            out.write(String.valueOf(_bft.get_depth()));
                            out.write(NL);
                            break;
                            
                        case MODE_NONE:
                            out.write("Error. Mode was not chosen."
                                +NL+"Aborting executing commands...");
                            break;
                            
                        default:
                            out.write("Error. Unexpected value of _mode = "+_mode
                                +NL+"Aborting executing commands..."+NL);
                            break;
                    }
                    
                    
                } else if (words[0].compareToIgnoreCase(CMD_AT) == 0) {
                    switch(_mode) {
                        case MODE_HT:
                            if ( _ht == null ) {
                                out.write("Error. HTable wasn't been created. "
                                    +NL+"Aborting executing commands..."+NL);
                                return false;
                            }
                            out.write("Error. No such information for HTable. ");
                            out.write(NL);
                            break;
                            
                        case MODE_SA:
                            if ( words.length < 2 ) {
                                out.write("Error. Not found argument in command \""
                                    +words[0]+"\"" + NL
                                    + "in line: "+num_of_line+NL+"Aborting executing commands..."+NL);
                                return false;
                            }
                            try {
                                int_arg_0 = Integer.parseInt(words[1]);
                            } catch (NumberFormatException exc) {
                                out.write("Error. Illegal argument \""
                                    +words[1]+"\" in command \""+line+"\""
                                    + NL + "in line: "+num_of_line+NL+"Aborting executing commands..."+NL);
                                return false;
                            }
                            if ( _sa == null ) {
                                out.write("Error. SArray wasn't been created. "
                                    +NL+"Aborting executing commands..."+NL);
                                return false;
                            }
                            out.write(_sa.get_at(int_arg_0));
                            out.write(NL);
                            break;
                            
                        case MODE_BFT:
                            if ( _bft == null ) {
                                out.write("Error. BFTree wasn't been created. "
                                    +NL+"Aborting executing commands..."+NL);
                                return false;
                            }
                            out.write("Error. No such information for BFTree. ");
                            out.write(NL);
                            break;
                            
                        case MODE_NONE:
                            out.write("Error. Mode was not chosen."
                                +NL+"Aborting executing commands...");
                            break;
                            
                        default:
                            out.write("Error. Unexpected value of _mode = "+_mode
                                +NL+"Aborting executing commands..."+NL);
                            break;
                    }
                    
                    
                } else {
                    out.write("Unknown command \""+words[0]+"\""
                            + " in line: "+num_of_line+NL+"Aborting executing commands..."+NL);
                    return false;
                }
            }
            return true;
        } catch(Exception exc) {
            System.out.println("Error executing commands:"+NL+exc.toString()
                    +NL+"Aborting executing commands..."+NL);
        }
        return true;
    }

    
    
    
    /** Считывает строку из входного потока in,
     * допуская, что строка может кончаться как "\n", так и "\r\n".
     * 
     * @param in - входной поток
     * @return: null - если поток окончен.
     *          [string] - строку
     * @throws IOException 
     */
    /*protected String read_new_line(BufferedReader in) throws IOException {
        StringBuilder stringB = new StringBuilder();
        char c[] = new char[1];
        boolean not_zero_symbols = false;
        while ( in.read(c,0,1) == 1) {
            not_zero_symbols = true;
            if (c[0] == '\r') continue;
            if (c[0] == '\n') break;
            stringB.append(c[0]);
        }
        return not_zero_symbols ? stringB.toString() : null;
    }*/
}
