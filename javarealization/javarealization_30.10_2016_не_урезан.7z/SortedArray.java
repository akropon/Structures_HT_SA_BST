/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javarealization;

/** Отсортированный массив.
 * 
 * Структура, содержащая в себе неотрицательные числа типа int.
 * Реализация отсортированного массива по неубыванию.
 * Поддерживает возможность динамического расширения при переполнении.
 * Поддерживает возможность повтора элементов (т.е. в структуре могут 
 * одновременно присутствовать элементы с совпадающими значениями).
 *
 * @author Akropon
 */
public class SortedArray {
    protected int [] data;              // массив с данными ( числами )
    protected int size;                 // текущее кол-во элементов 
    protected int max_available_size;   // текущий размер массива ´data´
    protected int extention_multiplier; // множитель динамического расширения массива
    
    /** Конструктор нового Отсортированного Массива
     * 
     * Создает новый пустой массив с доступной начальной памятью
     * под заданное кол-во элементов.
     * 
     * @param max_available_size > 0 - максимальное кол-во элементов в массиве до 
     * первого расширения
     * @param extention_multiplier > 1 - множитель динамического расширения (при 
     * переполнении массива data[] выделяется новая память под этот массив, с 
     * размером в 'extention_multiplier' раз больше предыдущего).
     */
    public SortedArray(int max_available_size, int extention_multiplier){
        if ( max_available_size < 0 ) max_available_size = 1;
        if ( extention_multiplier < 2 ) extention_multiplier = 2;
        
        
        this.max_available_size = max_available_size;
        this.data = new int[max_available_size];
        this.size = 0;
        this.extention_multiplier = extention_multiplier;
    }
    
    /** Возвращает элемент по заданному индексу
     * 
     * @param index - индекс
     * @return '-1' - если был введен недопустимый индекс
     *        [int] - элемент
     */
    public int get_at(int index) {
        if ( index < 0 || index >= size ) return -1;
        return data[index];
    }
    
    /** Возвращает текущее кол-во элементов в Отсортированном массиве
     * 
     * @return кол-во элементов
     */
    public int get_size() {
        return this.size;
    }
    
    /** Возвращает текущий размер массива ´data´
     * 
     * @return текущий размер массива ´data´
     */
    public int get_max_available_size() {
        return this.max_available_size;
    }
    
    /** Возвращает множитель динамического расширения массива
     * 
     * @return множитель динамического расширения массива
     */
    public int get_extention_multiplier() {
        return this.extention_multiplier;
    }
    
    /** Добавляет элемент в Осортированный массив.
     * 
     * Добавляет элемент с возможностью повторений.
     * В случае переполнения, расширяет массив с параллельной вставкой нового 
     * элемента с сортировки.
     * 
     * @param new_element >= 0 - добавляемый эдемент.
     * @return true - успех, false - ошибка добавления
     */
    public boolean add_element(int new_element) {
        if ( new_element < 0 ) return false;
        // Найдем индекс позиции для нового элемента
        int left_index = 0;
        int right_index = size;
        while ( left_index < right_index ) {
          if ( new_element<=data[(right_index+left_index)/2]) 
            right_index = (right_index+left_index)/2;  // ищем в левой половине
          else 
            left_index = (right_index+left_index)/2+1;  // ищем в правой половине
        }
        // left_index – индекс позиции для нового элемента
        // Теперь проверим массив на переполнение
        if ( size >= max_available_size) {
            // Переполнение есть. Выделяем место под расширенный массив.
            // Копируем данные из старого массива в новый с учетом добавления
            // нового элемента.
            int[] old_data = data;
            data = new int[max_available_size * extention_multiplier];
            for ( int i=0; i<left_index; i++) 
                data[i] = old_data[i];
            data[left_index] = new_element;
            for ( int i=left_index; i<size; i++) 
                data[i+1] = old_data[i];
            // обновляем параметры структуры
            size++;
            max_available_size *= extention_multiplier;
        } else {
            // Переполнения нет. Просто вставляем элемент.
            for ( int i=size; i>left_index; i--) 
                data[i] = data[i-1];
            data[left_index] = new_element;
            // обновляем параметры структуры
            size++;
        }
        return true;
    }
    
    /** Удаляет элемент по заданному индексу.
     * 
     * @param index - индекс
     * @return true - успех, false - ошибка удаления
     */
    public boolean delete_element_at(int index) {
        if (index < 0 || index >= size) return false;
        for ( int i=index; i<size-1; i++) {
            data[i] = data[i+1];
        }
        size--;
        return true;
    }
    
    /** Поиск элемента по значению
     * 
     * Ищет первый элемент с указанным значением по алгоритму
     * бинарного поиска и возвращает его индекс.
     * В случае, если такой элемент отсутствует, возвращает '-1'.
     * 
     * @param element - искомый элемент
     * @return : '-1' - искомый элемент отсутствует
     *           other - индекс первого найденного элемента
     */
    public int find_index_of_element(int element) {
        if ( element < 0 ) return -1;
        int left_index = 0;
        int right_index = size-1;
        while ( left_index <= right_index ) {
          if ( element==data[(right_index+left_index)/2] ) 
            return (right_index+left_index)/2;
          if ( element< data[(right_index+left_index)/2]) 
            right_index = (right_index+left_index)/2-1;  // ищем в левой половине
          else 
            left_index = (right_index+left_index)/2+1;  // ищем в правой половине
        }
        return  -1; // элемент не найден
    }
    
    /** Возвращает максимальный элемент массива
     * 
     * @return: '-1' - такого элемента нет
     *          other - макс. элемент
     */
    public int get_max_element() {
        if ( size > 0 )
            return data[size-1];
        else 
            return -1;
    }
    
    /** Возвращает минимальный элемент массива
     * 
     * @return: '-1' - такого элемента нет
     *          other - мин. элемент
     */
    public int get_min_element() {
        if ( size>0 )
            return data[0];
        else
            return -1;
    }
    
    /** Получить текущее состояние массива.
     * 
     * Возвращает строку, в которой записаны все элементы массива в порядке, 
     * в котором они хранятся в структуре.
     * 
     * @return строка содержимого массива
     */
    public String get_current_data() {
        if ( size == 0 ) return "array is empty";
        StringBuilder stringB = new StringBuilder();
        for ( int i=0; i<size; i++) {
            stringB.append(data[i]);
            stringB.append(' ');
        }
        return stringB.toString();
    }
    
    /** Получить текущее состояние массива.
     * 
     * Возвращает строку, в которой записаны значения всех параметров структуры.
     * В строке не записано содержимое массива data[].
     * 
     * @return строка состояния структуры
     */
    public String get_current_state() {
        return "size = "+size+"  max_available_size = "+max_available_size
                + "  extention_multiplier = "+extention_multiplier;
    }
}
